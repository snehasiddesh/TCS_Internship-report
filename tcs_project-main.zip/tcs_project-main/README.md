TCS iON 210 Internship:

Automate Identification & Recognition of Handwritten Text from an Image

Dataset Used Link: https://drive.google.com/drive/folders/1AIyqg6kQatNC_PsXMlj-r2Hxd6NaaXiZ

Model Developed Link: https://drive.google.com/drive/folders/1bpIcomr5_CnirnmtG9D9sjBFTqkgBM9e

Google colab Link: https://colab.research.google.com/drive/1gf-HcNKl5AGBgBsXCYg7M36lUWTXKKgS#scrollTo=CcZep_syjIay

I would like to thank TCS iON Rio 210 team for constantly guiding and providing support throughout the project.

